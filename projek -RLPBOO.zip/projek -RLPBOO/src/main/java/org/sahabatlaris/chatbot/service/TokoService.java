package org.sahabatlaris.chatbot.service;

import java.io.*;
import java.nio.file.*;

/**
 * Singleton yang menyimpan info toko ke file toko_data.json
 * di folder home user (~/.sahabatlaris/).
 * Dengan begitu perubahan dari AdminApp langsung terbaca oleh UserApp.
 */
public class TokoService {

    private static TokoService instance;

    // Lokasi file penyimpanan
    private static final Path DATA_DIR  =
        Paths.get(System.getProperty("user.home"), ".sahabatlaris");
    private static final Path DATA_FILE = DATA_DIR.resolve("toko_data.json");

    // ── Data toko ─────────────────────────────────────────────────────────────
    private String nama      = "SahabatLaris";
    private String tagline   = "Skincare Aman untuk Kulit Sensitif";
    private String deskripsi =
        "SahabatLaris adalah toko skincare yang berfokus pada produk-produk " +
        "aman dan lembut untuk kulit sensitif. Kami menyediakan berbagai produk " +
        "perawatan wajah berkualitas dengan bahan-bahan yang telah teruji secara " +
        "dermatologis dan cocok untuk semua jenis kulit sensitif.";
    private String kota     = "Yogyakarta";
    private String alamat   = "Jl. Kaliurang KM 5, No. 12\nSleman, Yogyakarta 55281";
    private String linkPeta = "maps.google.com/?q=Jl.+Kaliurang+KM+5+Sleman+Yogyakarta";

    // ── Jam operasional ───────────────────────────────────────────────────────
    private final String[] hari     = {"Senin","Selasa","Rabu","Kamis","Jumat","Sabtu","Minggu"};
    private boolean[] buka          = {true, true, true, true, true, true, false};
    private String[]  jamBuka       = {"08.00","08.00","08.00","08.00","08.00","09.00","09.00"};
    private String[]  jamTutup      = {"21.00","21.00","21.00","21.00","21.00","20.00","17.00"};

    private TokoService() {
        load(); // Baca dari file saat pertama kali dibuat
    }

    public static TokoService getInstance() {
        if (instance == null) instance = new TokoService();
        return instance;
    }

    // ── Getter / Setter ───────────────────────────────────────────────────────

    public String getNama()              { return nama; }
    public void   setNama(String v)      { this.nama = v; }

    public String getTagline()           { return tagline; }
    public void   setTagline(String v)   { this.tagline = v; }

    public String getDeskripsi()         { return deskripsi; }
    public void   setDeskripsi(String v) { this.deskripsi = v; }

    public String getKota()              { return kota; }
    public void   setKota(String v)      { this.kota = v; }

    public String getAlamat()            { return alamat; }
    public void   setAlamat(String v)    { this.alamat = v; }

    public String getLinkPeta()          { return linkPeta; }
    public void   setLinkPeta(String v)  { this.linkPeta = v; }

    public String[]  getHari()     { return hari; }
    public boolean[] getBuka()     { return buka; }
    public String[]  getJamBuka()  { return jamBuka; }
    public String[]  getJamTutup() { return jamTutup; }

    public void setBuka(int i, boolean v)    { buka[i]     = v; }
    public void setJamBuka(int i, String v)  { jamBuka[i]  = v; }
    public void setJamTutup(int i, String v) { jamTutup[i] = v; }

    // ── Simpan ke file JSON ───────────────────────────────────────────────────

    public void save() {
        try {
            Files.createDirectories(DATA_DIR);

            StringBuilder sb = new StringBuilder();
            sb.append("{\n");
            sb.append("  \"nama\": ").append(jsonStr(nama)).append(",\n");
            sb.append("  \"tagline\": ").append(jsonStr(tagline)).append(",\n");
            sb.append("  \"deskripsi\": ").append(jsonStr(deskripsi)).append(",\n");
            sb.append("  \"kota\": ").append(jsonStr(kota)).append(",\n");
            sb.append("  \"alamat\": ").append(jsonStr(alamat)).append(",\n");
            sb.append("  \"linkPeta\": ").append(jsonStr(linkPeta)).append(",\n");

            // Jam operasional sebagai array of objects
            sb.append("  \"jadwal\": [\n");
            for (int i = 0; i < hari.length; i++) {
                sb.append("    {\"hari\":").append(jsonStr(hari[i]))
                  .append(",\"buka\":").append(buka[i])
                  .append(",\"jamBuka\":").append(jsonStr(jamBuka[i]))
                  .append(",\"jamTutup\":").append(jsonStr(jamTutup[i]))
                  .append("}");
                if (i < hari.length - 1) sb.append(",");
                sb.append("\n");
            }
            sb.append("  ]\n");
            sb.append("}\n");

            Files.writeString(DATA_FILE, sb.toString());
        } catch (IOException e) {
            System.err.println("TokoService: gagal menyimpan data - " + e.getMessage());
        }
    }

    // ── Baca dari file JSON ───────────────────────────────────────────────────

    public void load() {
        if (!Files.exists(DATA_FILE)) return; // Pakai default jika belum ada file

        try {
            String json = Files.readString(DATA_FILE);

            nama      = ambilNilai(json, "nama",      nama);
            tagline   = ambilNilai(json, "tagline",   tagline);
            deskripsi = ambilNilai(json, "deskripsi", deskripsi);
            kota      = ambilNilai(json, "kota",      kota);
            alamat    = ambilNilai(json, "alamat",    alamat);
            linkPeta  = ambilNilai(json, "linkPeta",  linkPeta);

            // Parse array jadwal
            int jadwalStart = json.indexOf("\"jadwal\"");
            if (jadwalStart >= 0) {
                int arrStart = json.indexOf('[', jadwalStart);
                int arrEnd   = json.indexOf(']', arrStart);
                if (arrStart >= 0 && arrEnd > arrStart) {
                    String arrStr = json.substring(arrStart + 1, arrEnd);
                    String[] entries = arrStr.split("\\},\\s*\\{");
                    for (int i = 0; i < Math.min(entries.length, hari.length); i++) {
                        String e = entries[i].replace("{","").replace("}","");
                        buka[i]     = e.contains("\"buka\":true");
                        jamBuka[i]  = ambilNilai(e, "jamBuka",  jamBuka[i]);
                        jamTutup[i] = ambilNilai(e, "jamTutup", jamTutup[i]);
                    }
                }
            }
        } catch (Exception e) {
            System.err.println("TokoService: gagal membaca data - " + e.getMessage());
        }
    }

    // ── Helper JSON sederhana (tanpa library eksternal) ───────────────────────

    /** Escape string untuk JSON */
    private String jsonStr(String s) {
        if (s == null) return "\"\"";
        return "\"" + s.replace("\\", "\\\\")
                       .replace("\"", "\\\"")
                       .replace("\n", "\\n")
                       .replace("\r", "") + "\"";
    }

    /** Ambil nilai string dari JSON sederhana berdasarkan key */
    private String ambilNilai(String json, String key, String defaultVal) {
        String cari = "\"" + key + "\":";
        int idx = json.indexOf(cari);
        if (idx < 0) return defaultVal;
        int start = json.indexOf('"', idx + cari.length()) + 1;
        if (start <= 0) return defaultVal;

        StringBuilder result = new StringBuilder();
        boolean escape = false;
        for (int i = start; i < json.length(); i++) {
            char c = json.charAt(i);
            if (escape) {
                if (c == 'n') result.append('\n');
                else result.append(c);
                escape = false;
            } else if (c == '\\') {
                escape = true;
            } else if (c == '"') {
                break;
            } else {
                result.append(c);
            }
        }
        return result.toString();
    }
}
