package org.sahabatlaris.chatbot.Controller;

import org.sahabatlaris.chatbot.model.Produk;
import org.sahabatlaris.chatbot.ui.AppUI;
import org.sahabatlaris.chatbot.service.ManagedDataService;
import org.sahabatlaris.chatbot.service.TokoService;
import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.stage.Modality;
import javafx.stage.Stage;

import java.util.List;

public class AdminController {

    @FXML private TableView<Produk>           tabelProduk;
    @FXML private TableColumn<Produk, String> colNo;
    @FXML private TableColumn<Produk, String> colNama;
    @FXML private TableColumn<Produk, String> colKategori;
    @FXML private TableColumn<Produk, String> colHarga;
    @FXML private TableColumn<Produk, String> colKandungan;
    @FXML private TableColumn<Produk, String> colStatus;
    @FXML private TableColumn<Produk, Void>   colAksi;
    @FXML private Label                        labelJumlahProduk;
    @FXML private ComboBox<String>             filterKategori;
    @FXML private VBox                         panelDataProduk;
    @FXML private Button                       btnDataProduk;

    @FXML private VBox      panelInfoToko;
    @FXML private Button    btnInfoToko;
    @FXML private TextField namaToko;
    @FXML private TextField taglineToko;
    @FXML private TextArea  deskripsiToko;
    @FXML private TextArea  alamatToko;
    @FXML private TextField linkPeta;
    @FXML private TextField kotaToko;
    @FXML private VBox      jamOperasionalContainer;

    private final ManagedDataService     layananData     = new ManagedDataService();
    private final TokoService            tokoService     = TokoService.getInstance();
    private final ObservableList<Produk> produkObservable = FXCollections.observableArrayList();

    private CheckBox[]  toggleBuka;
    private TextField[] fieldJamBuka;
    private TextField[] fieldJamTutup;

    @FXML
    public void initialize() {
        setupTable();
        setupFilterKategori();
        isiDataInfoToko();
        setupJamOperasional();
        tampilkanPanel();
    }

    private void setupTable() {
        colNo.setCellValueFactory(cd -> {
            int idx = tabelProduk.getItems().indexOf(cd.getValue()) + 1;
            return new SimpleStringProperty(String.valueOf(idx));
        });
        colNama.setCellValueFactory(d -> d.getValue().namaProdukProperty());
        colKategori.setCellValueFactory(d -> d.getValue().kategoriProperty());
        colHarga.setCellValueFactory(d ->
            new SimpleStringProperty(d.getValue().getHargaFormatted()));
        colKandungan.setCellValueFactory(d -> d.getValue().kandunganProperty());

        colStatus.setCellFactory(col -> new TableCell<>() {
            @Override protected void updateItem(String item, boolean empty) {
                super.updateItem(item, empty);
                if (empty) { setGraphic(null); return; }
                Produk p = getTableView().getItems().get(getIndex());
                Label badge = new Label(p.isAktif() ? "Aktif" : "Non-Aktif");
                badge.getStyleClass().add("status-aktif");
                setGraphic(badge);
                setAlignment(Pos.CENTER);
            }
        });

        colAksi.setCellFactory(col -> new TableCell<>() {
            private final Button btnUbah  = new Button("Ubah");
            private final Button btnHapus = new Button("Hapus");
            private final HBox   box      = new HBox(6, btnUbah, btnHapus);
            {
                box.setAlignment(Pos.CENTER);
                btnUbah.getStyleClass().add("btn-ubah");
                btnHapus.getStyleClass().add("btn-hapus");
                btnUbah.setOnAction(e ->
                    showFormProduk(getTableView().getItems().get(getIndex())));
                btnHapus.setOnAction(e -> {
                    Produk p = getTableView().getItems().get(getIndex());
                    Alert c = new Alert(Alert.AlertType.CONFIRMATION,
                        "Hapus produk \"" + p.getNamaProduk() + "\"?",
                        ButtonType.YES, ButtonType.NO);
                    c.setHeaderText(null);
                    c.showAndWait().ifPresent(btn -> {
                        if (btn == ButtonType.YES) {
                            layananData.hapusProduk(p.getKodeProduk());
                            tampilkanPanel();
                        }
                    });
                });
            }
            @Override protected void updateItem(Void item, boolean empty) {
                super.updateItem(item, empty);
                setGraphic(empty ? null : box);
            }
        });

        tabelProduk.setItems(produkObservable);
    }

    private void setupFilterKategori() {
        filterKategori.getItems().addAll(layananData.getAllKategori());
        filterKategori.setValue("Semua Kategori");
        filterKategori.setOnAction(e -> tampilkanPanel());
    }

    private void isiDataInfoToko() {
        if (namaToko      != null) namaToko.setText(tokoService.getNama());
        if (taglineToko   != null) taglineToko.setText(tokoService.getTagline());
        if (deskripsiToko != null) deskripsiToko.setText(tokoService.getDeskripsi());
        if (kotaToko      != null) kotaToko.setText(tokoService.getKota());
        if (alamatToko    != null) alamatToko.setText(tokoService.getAlamat());
        if (linkPeta      != null) linkPeta.setText(tokoService.getLinkPeta());
    }

    private void setupJamOperasional() {
        if (jamOperasionalContainer == null) return;
        jamOperasionalContainer.getChildren().clear();

        String[]  hari     = tokoService.getHari();
        boolean[] buka     = tokoService.getBuka();
        String[]  jamBuka  = tokoService.getJamBuka();
        String[]  jamTutup = tokoService.getJamTutup();

        toggleBuka    = new CheckBox[hari.length];
        fieldJamBuka  = new TextField[hari.length];
        fieldJamTutup = new TextField[hari.length];

        for (int i = 0; i < hari.length; i++) {
            Label lblHari = new Label(hari[i]);
            lblHari.setMinWidth(70);
            lblHari.getStyleClass().add("field-label-sm");

            CheckBox cb = new CheckBox("Buka");
            cb.setSelected(buka[i]);
            toggleBuka[i] = cb;

            TextField tfBuka = new TextField(jamBuka[i]);
            tfBuka.setPrefWidth(72);
            tfBuka.getStyleClass().add("info-field");
            tfBuka.setDisable(!buka[i]);
            fieldJamBuka[i] = tfBuka;

            TextField tfTutup = new TextField(jamTutup[i]);
            tfTutup.setPrefWidth(72);
            tfTutup.getStyleClass().add("info-field");
            tfTutup.setDisable(!buka[i]);
            fieldJamTutup[i] = tfTutup;

            cb.selectedProperty().addListener((obs, old, val) -> {
                tfBuka.setDisable(!val);
                tfTutup.setDisable(!val);
            });

            Label dash = new Label("–");
            dash.setStyle("-fx-text-fill:#888;");

            HBox row = new HBox(12, lblHari, cb, tfBuka, dash, tfTutup);
            row.setAlignment(Pos.CENTER_LEFT);
            if (i >= 5)
                row.setStyle("-fx-background-color:#fff8f0;" +
                             "-fx-background-radius:6;-fx-padding:2 6;");

            jamOperasionalContainer.getChildren().add(row);
        }
    }

    @FXML public void tampilkanPanel() {
        String kat = filterKategori != null ? filterKategori.getValue() : "Semua Kategori";
        List<Produk> list = layananData.getProdukByKategori(kat);
        produkObservable.setAll(list);
        if (labelJumlahProduk != null)
            labelJumlahProduk.setText(list.size() + " produk");
    }

    @FXML public void showDataProduk() {
        panelDataProduk.setVisible(true);
        panelInfoToko.setVisible(false);
        setSidebarActive(btnDataProduk, btnInfoToko);
    }

    @FXML public void showInfoToko() {
        panelDataProduk.setVisible(false);
        panelInfoToko.setVisible(true);
        setSidebarActive(btnInfoToko, btnDataProduk);
    }

    private void setSidebarActive(Button active, Button inactive) {
        active.getStyleClass().remove("sidebar-btn");
        if (!active.getStyleClass().contains("sidebar-btn-active"))
            active.getStyleClass().add("sidebar-btn-active");
        inactive.getStyleClass().remove("sidebar-btn-active");
        if (!inactive.getStyleClass().contains("sidebar-btn"))
            inactive.getStyleClass().add("sidebar-btn");
    }

    @FXML
    public void simpanInfoToko() {
        // 1. Simpan data teks ke TokoService
        if (namaToko      != null) tokoService.setNama(namaToko.getText());
        if (taglineToko   != null) tokoService.setTagline(taglineToko.getText());
        if (deskripsiToko != null) tokoService.setDeskripsi(deskripsiToko.getText());
        if (kotaToko      != null) tokoService.setKota(kotaToko.getText());
        if (alamatToko    != null) tokoService.setAlamat(alamatToko.getText());
        if (linkPeta      != null) tokoService.setLinkPeta(linkPeta.getText());

        // 2. Simpan jam operasional ke TokoService
        if (toggleBuka != null) {
            for (int i = 0; i < toggleBuka.length; i++) {
                tokoService.setBuka(i, toggleBuka[i].isSelected());
                tokoService.setJamBuka(i, fieldJamBuka[i].getText());
                tokoService.setJamTutup(i, fieldJamTutup[i].getText());
            }
        }

        // 3. ✅ Tulis ke file agar UserApp bisa membacanya
        tokoService.save();

        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle("Berhasil");
        alert.setHeaderText(null);
        alert.setContentText(
            "✅ Info toko berhasil disimpan!\n" +
            "Perubahan akan langsung terlihat di halaman user.");
        alert.showAndWait();
    }

    @FXML public void showTambahProduk() { showFormProduk(null); }

    @FXML public void handleLogout() {
        try {
            Stage stage = (Stage) tabelProduk.getScene().getWindow();
            new AppUI().showAdminLogin(stage);
        } catch (Exception e) { e.printStackTrace(); }
    }

    private void showFormProduk(Produk existing) {
        Stage dialog = new Stage();
        dialog.initModality(Modality.APPLICATION_MODAL);
        dialog.setTitle(existing == null ? "Tambah Produk" : "Ubah Produk");

        VBox root = new VBox(16);
        root.setPadding(new Insets(24));
        root.setStyle("-fx-background-color:white;");

        Label title = new Label(existing == null ? "Tambah Produk Baru" : "Ubah Produk");
        title.setStyle("-fx-font-size:16px;-fx-font-weight:bold;-fx-text-fill:#1a1a2e;");

        TextField fNama = new TextField();
        fNama.setPromptText("Nama Produk");
        fNama.getStyleClass().add("info-field");

        ComboBox<String> fKategori = new ComboBox<>();
        fKategori.getItems().addAll("Pelembab","Toner","Serum","Pembersih muka",
            "Chemical Sunscreen","Tinted Sunscreen","Exfoliator");
        fKategori.setPromptText("Pilih Kategori");
        fKategori.setMaxWidth(Double.MAX_VALUE);

        TextField fHarga = new TextField();
        fHarga.setPromptText("Harga (angka)");
        fHarga.getStyleClass().add("info-field");

        TextArea fKandungan = new TextArea();
        fKandungan.setPromptText("Kandungan (pisah koma)");
        fKandungan.setPrefRowCount(2);
        fKandungan.setWrapText(true);
        fKandungan.getStyleClass().add("info-textarea");

        CheckBox fAktif = new CheckBox("Aktif");
        fAktif.setSelected(true);

        if (existing != null) {
            fNama.setText(existing.getNamaProduk());
            fKategori.setValue(existing.getKategori());
            fHarga.setText(String.valueOf(existing.getHarga()));
            fKandungan.setText(existing.getKandungan());
            fAktif.setSelected(existing.isAktif());
        }

        Label errMsg = new Label();
        errMsg.setStyle("-fx-text-fill:#e53e3e;-fx-font-size:12px;");

        Button btnBatal  = new Button("Batal");
        btnBatal.setStyle("-fx-background-color:#888;-fx-text-fill:white;" +
            "-fx-padding:6 16;-fx-background-radius:4;-fx-cursor:hand;");
        Button btnSimpan = new Button("Simpan");
        btnSimpan.getStyleClass().add("btn-tambah");

        btnBatal.setOnAction(e -> dialog.close());
        btnSimpan.setOnAction(e -> {
            if (fNama.getText().isEmpty() || fKategori.getValue() == null
                    || fHarga.getText().isEmpty()) {
                errMsg.setText("Nama, Kategori, dan Harga wajib diisi."); return;
            }
            long harga;
            try { harga = Long.parseLong(fHarga.getText()); }
            catch (NumberFormatException ex) {
                errMsg.setText("Harga harus berupa angka."); return;
            }
            if (existing == null) {
                layananData.tambahProduk(new Produk(layananData.generateKodeProduk(),
                    fNama.getText(), fKategori.getValue(), harga,
                    fKandungan.getText(), fAktif.isSelected()));
            } else {
                existing.setNamaProduk(fNama.getText());
                existing.setKategori(fKategori.getValue());
                existing.setHarga(harga);
                existing.setKandungan(fKandungan.getText());
                existing.setAktif(fAktif.isSelected());
                layananData.updateProduk(existing);
            }
            filterKategori.getItems().setAll(layananData.getAllKategori());
            filterKategori.setValue("Semua Kategori");
            tampilkanPanel();
            dialog.close();
        });

        HBox btnRow = new HBox(12, btnBatal, btnSimpan);
        btnRow.setAlignment(Pos.CENTER_RIGHT);

        root.getChildren().addAll(title,
            lf("Nama Produk", fNama), lf("Kategori", fKategori),
            lf("Harga", fHarga), lf("Kandungan", fKandungan),
            fAktif, errMsg, btnRow);

        Scene scene = new Scene(root, 380, 460);
        scene.getStylesheets().add(
            getClass().getResource("/org/sahabatlaris/chatbot/css/styles.css").toExternalForm());
        dialog.setScene(scene);
        dialog.showAndWait();
    }

    private VBox lf(String label, javafx.scene.Node field) {
        VBox box = new VBox(4);
        Label lbl = new Label(label);
        lbl.getStyleClass().add("field-label-sm");
        box.getChildren().addAll(lbl, field);
        return box;
    }
}
