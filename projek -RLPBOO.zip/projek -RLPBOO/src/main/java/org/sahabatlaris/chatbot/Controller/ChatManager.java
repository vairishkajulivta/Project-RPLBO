package org.sahabatlaris.chatbot.Controller;

import org.sahabatlaris.chatbot.model.Produk;
import org.sahabatlaris.chatbot.service.ChatbotService;
import org.sahabatlaris.chatbot.service.TokoService;
import javafx.animation.PauseTransition;
import javafx.fxml.FXML;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.*;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.*;
import javafx.util.Duration;

import java.io.InputStream;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.List;

public class ChatManager {

    @FXML private TextField  inputField;
    @FXML private VBox       chatContainer;
    @FXML private ScrollPane chatScrollPane;

    private final ChatbotService botService = new ChatbotService();
    private final TokoService    tokoService = TokoService.getInstance();
    private static final DateTimeFormatter TIME_FMT = DateTimeFormatter.ofPattern("HH.mm");

    // ── Cache gambar agar tidak reload terus ─────────────────────────────────
    private final java.util.Map<String, Image> imageCache = new java.util.HashMap<>();

    @FXML
    public void initialize() {
        addBotMessage(
            "Halo! Selamat datang di SahabatLaris 👋\n"
          + "Saya bisa membantu Anda mencari informasi produk skincare untuk kulit sensitif.\n\n"
          + "Coba tanyakan:\n"
          + "• Harga moisturizer berapa?\n"
          + "• Rekomendasi serum\n"
          + "• Produk untuk kulit sensitif\n"
          + "• Ketik 'semua produk' untuk melihat semua produk");
    }

    // ── Proses pesan ─────────────────────────────────────────────────────────

    @FXML
    public void prosesPesan() {
        String pesan = inputField.getText().trim();
        if (pesan.isEmpty()) return;

        addUserMessage(pesan);
        inputField.clear();

        HBox typingRow = createTypingIndicator();
        chatContainer.getChildren().add(typingRow);
        scrollToBottom();

        PauseTransition pause = new PauseTransition(Duration.millis(700));
        pause.setOnFinished(e -> {
            chatContainer.getChildren().remove(typingRow);

            String jawaban = botService.cariJawaban(pesan);
            List<Produk> produkList = botService.getProdukDariJawaban(pesan, jawaban);

            // Tampilkan kartu bergambar jika ada produk
            if (!produkList.isEmpty() && jawaban.contains("Rp.")) {
                addBotProductCards(produkList, jawaban);
            } else {
                addBotMessage(jawaban);
            }
        });
        pause.play();
    }

    // ── Bubble user ──────────────────────────────────────────────────────────

    private void addUserMessage(String text) {
        Label msg = new Label(text);
        msg.getStyleClass().add("bubble-user-text");
        msg.setWrapText(true);
        msg.setMaxWidth(360);

        VBox bubbleBox = new VBox(msg);
        bubbleBox.getStyleClass().add("bubble-user");

        Label time = new Label(LocalTime.now().format(TIME_FMT));
        time.getStyleClass().add("timestamp");

        VBox bubble = new VBox(4, bubbleBox, time);
        bubble.setAlignment(Pos.CENTER_RIGHT);

        HBox row = new HBox(bubble);
        row.setAlignment(Pos.CENTER_RIGHT);
        chatContainer.getChildren().add(row);
        scrollToBottom();
    }

    // ── Bubble bot teks biasa ────────────────────────────────────────────────

    private void addBotMessage(String text) {
        Label msg = new Label(text);
        msg.getStyleClass().add("bubble-bot-text");
        msg.setWrapText(true);
        msg.setMaxWidth(440);

        VBox bubbleBox = new VBox(msg);
        bubbleBox.getStyleClass().add("bubble-bot");

        Label time = new Label(LocalTime.now().format(TIME_FMT));
        time.getStyleClass().add("timestamp");

        VBox bubble = new VBox(4, bubbleBox, time);
        bubble.setAlignment(Pos.CENTER_LEFT);

        HBox row = new HBox(bubble);
        row.setAlignment(Pos.CENTER_LEFT);
        chatContainer.getChildren().add(row);
        scrollToBottom();
    }

    // ── Bubble kartu produk dengan gambar ────────────────────────────────────

    private void addBotProductCards(List<Produk> produkList, String teks) {
        VBox outer = new VBox(10);
        outer.getStyleClass().add("bubble-bot");
        outer.setMaxWidth(480);
        outer.setPadding(new Insets(12));

        // Header sebelum daftar produk
        String[] lines = teks.split("\n");
        if (lines.length > 0 && !lines[0].trim().startsWith("•")) {
            Label header = new Label(lines[0].trim());
            header.getStyleClass().add("bubble-bot-text");
            header.setStyle("-fx-font-weight: bold; -fx-font-size: 13px;");
            header.setWrapText(true);
            outer.getChildren().add(header);
        }

        // Kartu per produk
        for (Produk p : produkList) {
            outer.getChildren().add(buatKartuProduk(p));
        }

        Label time = new Label(LocalTime.now().format(TIME_FMT));
        time.getStyleClass().add("timestamp");

        VBox bubble = new VBox(4, outer, time);
        bubble.setAlignment(Pos.CENTER_LEFT);

        HBox row = new HBox(bubble);
        row.setAlignment(Pos.CENTER_LEFT);
        chatContainer.getChildren().add(row);
        scrollToBottom();
    }

    /**
     * Satu kartu produk: [Gambar | Nama, Kategori, Harga, Kandungan]
     * Gambar diload via getResourceAsStream agar bekerja di dalam JAR/classpath.
     */
    private HBox buatKartuProduk(Produk p) {

        // ── Load gambar ──────────────────────────────────────────────────────
        ImageView imgView = new ImageView();
        imgView.setFitWidth(90);
        imgView.setFitHeight(90);
        imgView.setPreserveRatio(true);
        imgView.setSmooth(true);

        Image img = loadGambar(p.getKodeProduk());
        imgView.setImage(img);

        StackPane imgFrame = new StackPane(imgView);
        imgFrame.setMinSize(98, 98);
        imgFrame.setPrefSize(98, 98);
        imgFrame.setStyle(
            "-fx-background-color: #f0f0f8;" +
            "-fx-border-color: #d0d0e8;" +
            "-fx-border-radius: 12;" +
            "-fx-background-radius: 12;"
        );

        // ── Info ─────────────────────────────────────────────────────────────
        Label lblNama = new Label(p.getNamaProduk());
        lblNama.setStyle("-fx-font-weight: bold; -fx-font-size: 13px; -fx-text-fill: #1a1a2e;");
        lblNama.setWrapText(true);
        lblNama.setMaxWidth(310);

        Label lblKategori = new Label("🏷 " + p.getKategori());
        lblKategori.setStyle("-fx-font-size: 11px; -fx-text-fill: #888888;");

        Label lblHarga = new Label(p.getHargaFormatted());
        lblHarga.setStyle("-fx-font-size: 14px; -fx-font-weight: bold; -fx-text-fill: #4B3FC8;");

        Label lblKandungan = new Label("✦ " + p.getKandungan());
        lblKandungan.setStyle("-fx-font-size: 11px; -fx-text-fill: #555555;");
        lblKandungan.setWrapText(true);
        lblKandungan.setMaxWidth(310);

        VBox info = new VBox(4, lblNama, lblKategori, lblHarga, lblKandungan);
        info.setAlignment(Pos.CENTER_LEFT);

        // ── Kartu ────────────────────────────────────────────────────────────
        HBox card = new HBox(12, imgFrame, info);
        card.setAlignment(Pos.CENTER_LEFT);
        card.setPadding(new Insets(10, 12, 10, 12));
        card.setStyle(
            "-fx-background-color: white;" +
            "-fx-border-color: #e0e0f0;" +
            "-fx-border-radius: 12;" +
            "-fx-background-radius: 12;" +
            "-fx-effect: dropshadow(gaussian, rgba(0,0,0,0.06), 6, 0, 0, 2);"
        );
        return card;
    }

    /**
     * Load gambar dari classpath resources.
     * Path: /org/sahabatlaris/chatbot/images/P001.png dst.
     * Menggunakan cache agar tidak reload berkali-kali.
     */
    private Image loadGambar(String kodeProduk) {
        if (imageCache.containsKey(kodeProduk)) {
            return imageCache.get(kodeProduk);
        }

        String path = "/org/sahabatlaris/chatbot/images/" + kodeProduk + ".png";
        try (InputStream is = getClass().getResourceAsStream(path)) {
            if (is != null) {
                Image img = new Image(is);
                imageCache.put(kodeProduk, img);
                return img;
            }
        } catch (Exception ex) {
            System.err.println("Gagal load gambar: " + path + " - " + ex.getMessage());
        }

        // Fallback: gambar placeholder dari canvas
        Image placeholder = buatPlaceholder(kodeProduk);
        imageCache.put(kodeProduk, placeholder);
        return placeholder;
    }

    /** Placeholder jika file gambar tidak ditemukan di classpath. */
    private Image buatPlaceholder(String kode) {
        javafx.scene.canvas.Canvas c = new javafx.scene.canvas.Canvas(90, 90);
        var gc = c.getGraphicsContext2D();
        gc.setFill(javafx.scene.paint.Color.web("#e8e8f4"));
        gc.fillRoundRect(0, 0, 90, 90, 14, 14);
        gc.setFill(javafx.scene.paint.Color.web("#9090c0"));
        gc.setFont(javafx.scene.text.Font.font("System",
            javafx.scene.text.FontWeight.BOLD, 16));
        gc.fillText(kode, 10, 52);
        return c.snapshot(null, null);
    }

    // ── Typing indicator ─────────────────────────────────────────────────────

    private HBox createTypingIndicator() {
        Label dots = new Label("•••");
        dots.setStyle("-fx-text-fill: #4B3FC8; -fx-font-size: 18px;");
        VBox bubble = new VBox(dots);
        bubble.getStyleClass().add("typing-indicator");
        HBox row = new HBox(bubble);
        row.setAlignment(Pos.CENTER_LEFT);
        return row;
    }

    private void scrollToBottom() {
        chatContainer.layout();
        chatScrollPane.setVvalue(1.0);
    }

    // ── Info Toko ─────────────────────────────────────────────────────────────

    @FXML
    public void showInfoToko() {
        // Baca ulang dari file agar selalu dapat data terbaru dari Admin
        tokoService.load();

        Stage dialog = new Stage();
        dialog.initModality(Modality.APPLICATION_MODAL);
        dialog.setTitle("Info Toko - " + tokoService.getNama());

        VBox header = new VBox(4);
        header.setAlignment(Pos.CENTER);
        header.setPadding(new Insets(28, 20, 20, 20));
        header.setStyle("-fx-background-color:#4B3FC8;");
        Label iconLbl = new Label("🏪"); iconLbl.setStyle("-fx-font-size:36px;");
        Label namaLbl = new Label(tokoService.getNama());
        namaLbl.setStyle("-fx-font-size:22px;-fx-font-weight:bold;-fx-text-fill:white;");
        Label tagLbl = new Label(tokoService.getTagline());
        tagLbl.setStyle("-fx-font-size:13px;-fx-text-fill:#c0b8ff;");
        header.getChildren().addAll(iconLbl, namaLbl, tagLbl);

        VBox konten = new VBox(18);
        konten.setPadding(new Insets(24, 28, 24, 28));
        konten.setStyle("-fx-background-color:white;");

        Label deskLbl = new Label(tokoService.getDeskripsi());
        deskLbl.setWrapText(true);
        deskLbl.setStyle("-fx-font-size:12px;-fx-text-fill:#555;-fx-line-spacing:3;");
        konten.getChildren().addAll(deskLbl, new Separator());
        konten.getChildren().add(buatBaris("📍","Alamat",      tokoService.getAlamat()));
        konten.getChildren().add(buatBaris("🏙","Kota",        tokoService.getKota()));
        konten.getChildren().add(buatBaris("🗺","Google Maps", tokoService.getLinkPeta()));
        konten.getChildren().add(new Separator());

        Label lblJam = new Label("🕐  Jam Operasional");
        lblJam.setStyle("-fx-font-size:13px;-fx-font-weight:bold;-fx-text-fill:#1a1a2e;");
        konten.getChildren().add(lblJam);

        GridPane grid = new GridPane();
        grid.setHgap(16); grid.setVgap(8);
        grid.setPadding(new Insets(4, 0, 0, 4));

        String[]  hari     = tokoService.getHari();
        boolean[] buka     = tokoService.getBuka();
        String[]  jamBuka  = tokoService.getJamBuka();
        String[]  jamTutup = tokoService.getJamTutup();

        for (int i = 0; i < hari.length; i++) {
            Label hariLbl = new Label(hari[i]);
            hariLbl.setStyle("-fx-font-size:12px;-fx-text-fill:#444;-fx-min-width:80;");
            Label jamLbl, statusLbl;
            if (buka[i]) {
                jamLbl = new Label(jamBuka[i] + " – " + jamTutup[i]);
                jamLbl.setStyle("-fx-font-size:12px;-fx-font-weight:bold;-fx-text-fill:#4B3FC8;");
                statusLbl = new Label("● Buka");
                statusLbl.setStyle("-fx-font-size:11px;-fx-text-fill:#2D8B6F;");
            } else {
                jamLbl = new Label("–");
                jamLbl.setStyle("-fx-font-size:12px;-fx-text-fill:#aaa;");
                statusLbl = new Label("● Tutup");
                statusLbl.setStyle("-fx-font-size:11px;-fx-text-fill:#e53e3e;");
            }
            grid.add(hariLbl, 0, i);
            grid.add(jamLbl, 1, i);
            grid.add(statusLbl, 2, i);
        }
        konten.getChildren().add(grid);

        ScrollPane scrollKonten = new ScrollPane(konten);
        scrollKonten.setFitToWidth(true);
        scrollKonten.setHbarPolicy(ScrollPane.ScrollBarPolicy.NEVER);
        scrollKonten.setStyle("-fx-background-color:white;-fx-border-color:transparent;");
        VBox.setVgrow(scrollKonten, Priority.ALWAYS);

        Button btnTutup = new Button("Tutup");
        btnTutup.setStyle("-fx-background-color:#4B3FC8;-fx-text-fill:white;" +
            "-fx-font-size:13px;-fx-padding:9 32;-fx-background-radius:8;-fx-cursor:hand;");
        btnTutup.setOnAction(e -> dialog.close());

        HBox footer = new HBox(btnTutup);
        footer.setAlignment(Pos.CENTER_RIGHT);
        footer.setPadding(new Insets(12, 28, 16, 28));
        footer.setStyle("-fx-background-color:#f5f5fb;" +
            "-fx-border-color:#e0e0f0;-fx-border-width:1 0 0 0;");

        VBox root = new VBox(header, scrollKonten, footer);
        VBox.setVgrow(scrollKonten, Priority.ALWAYS);
        root.setStyle("-fx-background-color:white;");

        Scene scene = new Scene(root, 460, 620);
        dialog.setScene(scene);
        dialog.setResizable(true);
        dialog.setMinHeight(500);
        dialog.show();
    }

    private HBox buatBaris(String ikon, String label, String nilai) {
        Label ikonLbl  = new Label(ikon); ikonLbl.setStyle("-fx-font-size:16px;-fx-min-width:24;");
        Label labelLbl = new Label(label + ":"); labelLbl.setStyle("-fx-font-size:12px;-fx-text-fill:#888;-fx-min-width:90;");
        Label nilaiLbl = new Label(nilai); nilaiLbl.setStyle("-fx-font-size:12px;-fx-text-fill:#222;");
        nilaiLbl.setWrapText(true); nilaiLbl.setMaxWidth(260);
        HBox baris = new HBox(10, ikonLbl, labelLbl, nilaiLbl);
        baris.setAlignment(Pos.TOP_LEFT);
        return baris;
    }

    // ── Riwayat Chat ─────────────────────────────────────────────────────────

    private static final java.time.format.DateTimeFormatter DATE_FMT =
        java.time.format.DateTimeFormatter.ofPattern("dd MMM yyyy");
    private final java.util.List<String[]> riwayatList = new java.util.ArrayList<>();
    private final java.time.LocalDate tanggalSesi = java.time.LocalDate.now();

    @FXML
    public void showRiwayat() {
        Stage dialog = new Stage();
        dialog.initModality(Modality.APPLICATION_MODAL);
        dialog.setTitle("Riwayat Chat");

        HBox header = new HBox(10);
        header.setAlignment(Pos.CENTER_LEFT);
        header.setPadding(new Insets(16, 20, 16, 20));
        header.setStyle("-fx-background-color:#4B3FC8;");
        Label iconLbl = new Label("🕐"); iconLbl.setStyle("-fx-font-size:20px;");
        Label titleLbl = new Label("Riwayat Percakapan");
        titleLbl.setStyle("-fx-font-size:15px;-fx-font-weight:bold;-fx-text-fill:white;");
        Label subLbl = new Label("Sesi: " + tanggalSesi.format(DATE_FMT) +
            "  •  " + riwayatList.size() + " pesan");
        subLbl.setStyle("-fx-font-size:11px;-fx-text-fill:#c0b8ff;");
        VBox headerText = new VBox(2, titleLbl, subLbl);
        Region spacer = new Region(); HBox.setHgrow(spacer, Priority.ALWAYS);
        Button btnHapus = new Button("🗑 Hapus Semua");
        btnHapus.setStyle("-fx-background-color:rgba(255,255,255,0.2);-fx-text-fill:white;" +
            "-fx-font-size:11px;-fx-padding:5 12;-fx-background-radius:6;-fx-cursor:hand;");
        header.getChildren().addAll(iconLbl, headerText, spacer, btnHapus);

        VBox isiRiwayat = new VBox(10);
        isiRiwayat.setPadding(new Insets(16));
        renderRiwayat(isiRiwayat);

        ScrollPane scroll = new ScrollPane(isiRiwayat);
        scroll.setFitToWidth(true);
        scroll.setStyle("-fx-background-color:#f5f5fb;-fx-border-color:transparent;");
        VBox.setVgrow(scroll, Priority.ALWAYS);

        btnHapus.setOnAction(e -> {
            Alert c = new Alert(Alert.AlertType.CONFIRMATION,
                "Hapus semua riwayat chat sesi ini?", ButtonType.YES, ButtonType.NO);
            c.setHeaderText(null);
            c.showAndWait().ifPresent(btn -> {
                if (btn == ButtonType.YES) {
                    riwayatList.clear();
                    renderRiwayat(isiRiwayat);
                    subLbl.setText("Sesi: " + tanggalSesi.format(DATE_FMT) + "  •  0 pesan");
                }
            });
        });

        Button btnTutup = new Button("✕  Tutup");
        btnTutup.setStyle("-fx-background-color:#4B3FC8;-fx-text-fill:white;" +
            "-fx-font-size:13px;-fx-padding:8 28;-fx-background-radius:8;-fx-cursor:hand;");
        btnTutup.setOnAction(e -> dialog.close());
        HBox footer = new HBox(btnTutup);
        footer.setAlignment(Pos.CENTER_RIGHT);
        footer.setPadding(new Insets(12, 20, 12, 20));
        footer.setStyle("-fx-background-color:#f0f0f8;-fx-border-color:#e0e0f0;-fx-border-width:1 0 0 0;");

        VBox root = new VBox(header, scroll, footer);
        VBox.setVgrow(scroll, Priority.ALWAYS);
        root.setStyle("-fx-background-color:#f5f5fb;");
        Scene scene = new Scene(root, 520, 580);
        dialog.setScene(scene);
        dialog.show();
        scroll.layout();
        scroll.setVvalue(1.0);
    }

    private void renderRiwayat(VBox container) {
        container.getChildren().clear();
        container.setAlignment(Pos.TOP_LEFT);
        if (riwayatList.isEmpty()) {
            Label k = new Label("Belum ada riwayat percakapan.");
            k.setStyle("-fx-text-fill:#aaa;-fx-font-size:13px;-fx-padding:20;");
            container.setAlignment(Pos.CENTER);
            container.getChildren().add(k);
            return;
        }
        Label tglLabel = new Label("── " + tanggalSesi.format(DATE_FMT) + " ──");
        tglLabel.setStyle("-fx-font-size:11px;-fx-text-fill:#bbb;");
        HBox tglRow = new HBox(tglLabel);
        tglRow.setAlignment(Pos.CENTER);
        tglRow.setPadding(new Insets(0, 0, 8, 0));
        container.getChildren().add(tglRow);
        for (String[] entry : riwayatList) {
            boolean isUser = "USER".equals(entry[0]);
            Label badge = new Label(isUser ? "Anda" : "🤖 SahabatLarisBot");
            badge.setStyle("-fx-font-size:10px;-fx-font-weight:bold;-fx-padding:0 2;" +
                "-fx-text-fill:" + (isUser ? "#4B3FC8" : "#2D8B6F") + ";");
            Label pesanLbl = new Label(entry[1]);
            pesanLbl.setWrapText(true); pesanLbl.setMaxWidth(370);
            pesanLbl.setStyle("-fx-font-size:12px;-fx-text-fill:#222;-fx-padding:9 13;" +
                "-fx-background-color:" + (isUser ? "#eeeeff" : "white") + ";" +
                "-fx-background-radius:10;-fx-border-color:" +
                (isUser ? "#c8c8f0" : "#e0e0e8") + ";-fx-border-radius:10;");
            Label waktuLbl = new Label(entry[2]);
            waktuLbl.setStyle("-fx-font-size:10px;-fx-text-fill:#bbb;-fx-padding:0 2;");
            VBox bubble = new VBox(3, badge, pesanLbl, waktuLbl);
            bubble.setAlignment(isUser ? Pos.CENTER_RIGHT : Pos.CENTER_LEFT);
            bubble.setMaxWidth(400);
            HBox row = new HBox(bubble);
            row.setAlignment(isUser ? Pos.CENTER_RIGHT : Pos.CENTER_LEFT);
            row.setPadding(new Insets(3, 0, 3, 0));
            container.getChildren().add(row);
        }
    }

    // ── Bantuan ───────────────────────────────────────────────────────────────

    @FXML
    public void showBantuan() {
        addBotMessage(
            "Bantuan:\n"
          + "• Ketik nama produk untuk info harga\n"
          + "• Ketik kategori: moisturizer, toner, serum, sunscreen\n"
          + "• Ketik 'semua produk' untuk lihat semua\n"
          + "• Tanya rekomendasi untuk kulit sensitif");
    }

    public void tampilPesan(String msg) { System.out.println(msg); }
}
